﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Linq.Expressions;
using System.Net.NetworkInformation;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp1.Properties;

namespace WindowsFormsApp1

{
    public partial class Form3 : Form

    {
        public Form3()
        {
            InitializeComponent();
        }

    private void button1_Click(object sender, EventArgs e)
        {

            string BaglantiAdresi = "Server=NILSU\\SQLEXPRESS;Database=pişt;User Id=pişt;Password=123; connection timeout=30;";
            SqlConnection Baglanti = new SqlConnection();
            Baglanti.ConnectionString = BaglantiAdresi;
            Baglanti.Open();

            string sqlQuery = "SELECT * FROM " + textBox6.Text + "where";

            using (SqlCommand command = new SqlCommand(sqlQuery, Baglanti))
            {

                using (SqlDataReader reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        if(textBox6.Text == "Users")
                        {
                            string data = reader["Username"].ToString();
                            richTextBox1.AppendText(data + Environment.NewLine);
                        }else
                        {
                            string data = reader["isim"].ToString();
                            richTextBox1.AppendText(data + Environment.NewLine);
                        }


                        
                                }
                }
            }

        }
        int counter = -1;

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
   
        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }
    private void button8_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxArray = new TextBox[] { textBox2, textBox3, textBox4 };

            counter ++;
            textBoxArray[counter].Text = textBox1.Text;
            textBox1.Text = "";
            TextBox txtRun = new TextBox();
            txtRun.Name = "txtDynamic";
            txtRun.Location = new System.Drawing.Point(20, 18);
            txtRun.Size = new System.Drawing.Size(200, 25);
            // Add the textbox control to the form's control collection         
            this.Controls.Add(txtRun);
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            TextBox[] textBoxArray = new TextBox[] { textBox2, textBox3, textBox4 };

            counter++;
            textBoxArray[counter].Text = textBox1.Text;
            textBox1.Text = "";
            TextBox txtRun = new TextBox();
            txtRun.Name = "txtDynamic";
            txtRun.Location = new System.Drawing.Point(20, 18);
            txtRun.Size = new System.Drawing.Size(200, 25);
            // Add the textbox control to the form's control collection         
            this.Controls.Add(txtRun);
        }

        private void button8_Click_1(object sender, EventArgs e)
        {

        }
    }
}


