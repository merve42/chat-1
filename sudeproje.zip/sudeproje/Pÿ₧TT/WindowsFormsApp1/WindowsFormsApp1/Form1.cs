﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Collections;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        SqlConnection Baglanti;
        public Form1()
        {
            InitializeComponent();
        }


        private void button1_Click(object sender, EventArgs e)
        {

            string BaglantiAdresi = "Server=NILSU\\SQLEXPRESS;Database=pişt;User Id=pişt;Password=123; connection timeout=30;";
            SqlConnection Baglanti = new SqlConnection();
            Baglanti.ConnectionString = BaglantiAdresi;
            Baglanti.Open();
            MessageBox.Show("Bağlantı Açıldı.");




            string KullaniciAdi = textBox1.Text;
            string sifre = textBox2.Text;
            Form3 form3 = new Form3();
            if (KullaniciAdi.Length != 0 && sifre.Length != 0)
            {
                string query = "Insert Into Table_isim(isim) Values('" + textBox1.Text + "')";
                SqlCommand command = new SqlCommand(query, Baglanti);
                command.ExecuteNonQuery();
                MessageBox.Show(textBox1.Text);

                form3.Show();
            }
            else
            {

                MessageBox.Show("Kullanıcı adı ve şifre boş bırakılmaz ");
            }
        }

       
      private void button2_Click(object sender, EventArgs e)
        {
          Form2 form2 = new Form2();
            form2.Show();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            textBox2.UseSystemPasswordChar = true;
        }
    }
}
